

/**
 * Test lớp Sinh Viên
 * MSSV:24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Tạo sv1 - chính mình
        SinhVien sv1 = new SinhVien(24698761, "Tran Van Trieu", 8.5f, 7.5f);
        //Tạo sv2 - bạn thân
        SinhVien sv2 = new SinhVien(24700001, "Vu Minh Tri", 7.0f, 8.0f);

        //Tạo sv3 - Tự nhập
        SinhVien sv3 = new SinhVien();
        System.out.println("Nhập thông tin sinh viên 3:");
        System.out.print("Mã sinh viên: ");
        sv3.setMaSV(scanner.nextInt());
        scanner.nextLine();
        System.out.print("Họ tên: ");
        sv3.setHoTen(scanner.nextLine());
        System.out.print("Điểm LT: ");
        sv3.setDiemLT(scanner.nextDouble());
        System.out.print("Điểm TH: ");
        sv3.setDiemTH(scanner.nextDouble());


        System.out.println("\nDanh sách sinh viên:");
        System.out.println(String.format("| %-10s | %-30s | %-10s | %-10s | %-10s |",
                "MSSV", "Họ tên", "Điểm LT", "Điểm TH", "Điểm TB"));
        System.out.println("-------------------");
        System.out.println(sv1.toString());
        System.out.println(sv2.toString());
        System.out.println(sv3.toString());

        scanner.close();
    }
}