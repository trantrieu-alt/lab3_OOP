/**
 * lớp Test Hang Thuc Pham
 * MSSV:24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */

import java.util.Scanner;

public class Test
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập thông tin hàng 1:");
        System.out.print("Mã hàng: ");
        String maHang1 = scanner.nextLine();
        System.out.print("Tên hàng: ");
        String tenHang1 = scanner.nextLine();
        System.out.print("Đơn giá: ");
        double donGia1 = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Ngày sản xuất (dd/MM/yyyy): ");
        String ngaySanXuat1 = scanner.nextLine();
        System.out.print("Ngày hết hạn (dd/MM/yyyy): ");
        String ngayHetHan1 = scanner.nextLine();

        HangThucPham ht1 = new HangThucPham(maHang1, tenHang1, donGia1, ngaySanXuat1, ngayHetHan1);
        System.out.println("\nThông tin hàng 1: " + ht1);

        // Tạo và test với constructor chỉ mã hàng
        System.out.print("\nNhập mã hàng cho hàng 2: ");
        String maHang2 = scanner.nextLine();
        HangThucPham ht2 = new HangThucPham(maHang2);
        System.out.println("Thông tin hàng 2: " + ht2);

        // test dữ liệu không hợp lệ
        System.out.println("\nThay đổi thông tin hàng 2:");
        ht2.setTenHang(""); // Gán mặc định
        ht2.setDonGia(-500); // Gán mặc định
        ht2.setNgaySanXuat("25/09/2024"); // Hợp lệ
        ht2.setNgayHetHan("20/09/2024"); // Sẽ gán mặc định vì trước ngày sản xuất
        System.out.println("Thông tin hàng 2 sau khi thay đổi: " + ht2);

        scanner.close();
    }
}