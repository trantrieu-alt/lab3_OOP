/**
 * lớp Thuc Pham
 * MSSV:24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.DecimalFormat;

public class HangThucPham {
    private final String maHang;
    private String tenHang;
    private double donGia;
    private LocalDate ngaySanXuat;
    private LocalDate ngayHetHan;

    public HangThucPham(String maHang, String tenHang, double donGia, String ngaySanXuat, String ngayHetHan) {

        this.maHang = (maHang == null || maHang.trim().isEmpty()) ? "MH_DEFAULT" : maHang.trim();
        this.tenHang = (tenHang == null || tenHang.trim().isEmpty()) ? "Hàng không tên" : tenHang.trim();
        this.donGia = (donGia <= 0) ? 1000.0 : donGia;



        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            this.ngaySanXuat = LocalDate.parse(ngaySanXuat, formatter);
        } catch (Exception e) {
            this.ngaySanXuat = LocalDate.now(); // Mặc định là ngày hiện tại
        }
        try {
            this.ngayHetHan = LocalDate.parse(ngayHetHan, formatter);
            if (this.ngayHetHan.isBefore(this.ngaySanXuat)) {
                this.ngayHetHan = this.ngaySanXuat.plusDays(1); // Đảm bảo hết hạn sau sản xuất
            }
        } catch (Exception e) {
            this.ngayHetHan = this.ngaySanXuat.plusDays(1); // Mặc định 1 ngày sau sản xuất
        }
    }

    public HangThucPham(String maHang) {
        this.maHang = (maHang == null || maHang.trim().isEmpty()) ? "MH_DEFAULT" : maHang.trim();
        this.tenHang = "Hàng không tên";
        this.donGia = 1000.0;
        this.ngaySanXuat = LocalDate.now();
        this.ngayHetHan = LocalDate.now().plusDays(1);
    }

    // Getters
    public String getMaHang() {
        return maHang;
    }

    public String getTenHang() {
        return tenHang;
    }

    public double getDonGia() {
        return donGia;
    }

    public LocalDate getNgaySanXuat() {
        return ngaySanXuat;
    }

    public LocalDate getNgayHetHan() {
        return ngayHetHan;
    }

    public void setTenHang(String tenHang) {
        this.tenHang = (tenHang == null || tenHang.trim().isEmpty()) ? "Hàng không tên" : tenHang.trim();
    }

    public void setDonGia(double donGia) {
        this.donGia = (donGia <= 0) ? 1000.0 : donGia;
    }

    public void setNgaySanXuat(String ngaySanXuat) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            LocalDate nsx = LocalDate.parse(ngaySanXuat, formatter);
            if (nsx.isBefore(LocalDate.now()) || nsx.isAfter(this.ngayHetHan)) {
                this.ngaySanXuat = LocalDate.now();
            } else {
                this.ngaySanXuat = nsx;
            }
        } catch (Exception e) {
            this.ngaySanXuat = LocalDate.now();
        }
    }

    public void setNgayHetHan(String ngayHetHan) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            LocalDate nhh = LocalDate.parse(ngayHetHan, formatter);
            if (nhh.isBefore(this.ngaySanXuat)) {
                this.ngayHetHan = this.ngaySanXuat.plusDays(1);
            } else {
                this.ngayHetHan = nhh;
            }
        } catch (Exception e) {
            this.ngayHetHan = this.ngaySanXuat.plusDays(1);
        }
    }

    public boolean isHetHan() {
        return LocalDate.now().isAfter(this.ngayHetHan);
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#,###");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "Mã hàng: " + maHang + ", Tên hàng: " + tenHang +
                ", Đơn giá: " + df.format(donGia) + " VNĐ, " +
                "Ngày sản xuất: " + ngaySanXuat.format(dateFormatter) +
                ", Ngày hết hạn: " + ngayHetHan.format(dateFormatter) +
                ", Trạng thái: " + (isHetHan() ? "Đã hết hạn" : "Chưa hết hạn");
    }
}