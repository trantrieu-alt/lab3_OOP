package iuh.fit.sv;
/**
 * Class test Phương Tiện
 * MSSV:24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */

import java.util.Scanner;

public class VehicleTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vehicle xe1 = null, xe2 = null, xe3 = null;
        int choice;
        do {
            System.out.println("\n=== MENU QUẢN LÝ XE ===");
            System.out.println("1. Nhập thông tin và tạo các đối tượng xe1, xe2, xe3");
            System.out.println("2. Xuất bảng kê khai tiền thuế trước bạ của các xe");
            System.out.println("3. Thoát");
            System.out.print("Nhập lựa chọn (1-3): ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Xóa bộ đệm

            switch (choice) {
                case 1:
                    // Nhập thông tin cho xe1
                    System.out.println("\nNhập thông tin xe 1:");
                    System.out.print("Mã xe: ");
                    String maXe1 = scanner.nextLine();
                    System.out.print("Tên xe: ");
                    String tenXe1 = scanner.nextLine();
                    System.out.print("Dung tích xy-lanh (cc): ");
                    int dungTich1 = scanner.nextInt();
                    System.out.print("Trị giá xe (VND): ");
                    double triGia1 = scanner.nextDouble();
                    xe1 = new Vehicle(maXe1, tenXe1, dungTich1, triGia1);

                    // Nhập thông tin cho xe2
                    System.out.println("\nNhập thông tin xe 2:");
                    scanner.nextLine(); // Xóa bộ đệm
                    System.out.print("Mã xe: ");
                    String maXe2 = scanner.nextLine();
                    System.out.print("Tên xe: ");
                    String tenXe2 = scanner.nextLine();
                    System.out.print("Dung tích xy-lanh (cc): ");
                    int dungTich2 = scanner.nextInt();
                    System.out.print("Trị giá xe (VND): ");
                    double triGia2 = scanner.nextDouble();
                    xe2 = new Vehicle(maXe2, tenXe2, dungTich2, triGia2);

                    // Nhập thông tin cho xe3
                    System.out.println("\nNhập thông tin xe 3:");
                    scanner.nextLine(); // Xóa bộ đệm
                    System.out.print("Mã xe: ");
                    String maXe3 = scanner.nextLine();
                    System.out.print("Tên xe: ");
                    String tenXe3 = scanner.nextLine();
                    System.out.print("Dung tích xy-lanh (cc): ");
                    int dungTich3 = scanner.nextInt();
                    System.out.print("Trị giá xe (VND): ");
                    double triGia3 = scanner.nextDouble();
                    xe3 = new Vehicle(maXe3, tenXe3, dungTich3, triGia3);
                    System.out.println("Đã nhập thông tin 3 xe thành công!");
                    break;

                case 2:
                    // Xuất bảng kê khai thuế
                    System.out.println("\nBảng kê khai tiền thuế trước bạ:");
                    System.out.println(String.format("%-10s %-20s %-10s %-15s %-15s",
                            "Mã xe", "Tên xe", "Dung tích", "Trị giá", "Thuế trước bạ"));
                    System.out.println("-------------------------------------------------------------");
                    if (xe1 != null) System.out.println(xe1.toString());
                    if (xe2 != null) System.out.println(xe2.toString());
                    if (xe3 != null) System.out.println(xe3.toString());
                    break;

                case 3:
                    System.out.println("Thoát chương trình!");
                    break;

                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng chọn lại.");
            }
        } while (choice != 3);

        scanner.close();
    }
}