package iuh.fit.sv;

/**
 * Class Phương Tiện
 * MSSV:24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */
public class Vehicle {
    private String maXe;
    private String tenXe;
    private int dungTich;
    private double triGia;

    public Vehicle() {
        this.maXe = "";
        this.tenXe = "";
        this.dungTich = 0;
        this.triGia = 0.0;
    }

    public Vehicle(String maXe, String tenXe, int dungTich, double triGia) {
        this.maXe = maXe;
        this.tenXe = tenXe;
        this.dungTich = dungTich;
        this.triGia = triGia;
    }

    public String getMaXe() {
        return maXe;
    }

    public void setMaXe(String maXe) {
        this.maXe = maXe;
    }

    public String getTenXe() {
        return tenXe;
    }

    public void setTenXe(String tenXe) {
        this.tenXe = tenXe;
    }

    public int getDungTich() {
        return dungTich;
    }

    public void setDungTich(int dungTich) {
        this.dungTich = dungTich;
    }

    public double getTriGia() {
        return triGia;
    }

    public void setTriGia(double triGia) {
        this.triGia = triGia;
    }

    public double tinhThueTruocBa() {
        if (dungTich < 100) {
            return triGia * 0.01; // 1% trị giá xe
        } else if (dungTich <= 200) {
            return triGia * 0.03; // 3% trị giá xe
        } else {
            return triGia * 0.05; // 5% trị giá xe
        }
    }

    @Override
    public String toString() {
        return String.format("%-10s %-20s %-10d %-15.2f %-15.2f",
                maXe, tenXe, dungTich, triGia, tinhThueTruocBa());
    }
}