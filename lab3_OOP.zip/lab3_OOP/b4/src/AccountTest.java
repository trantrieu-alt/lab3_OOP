
/**
 * Class Test
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */
import java.util.Scanner;

public class AccountTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AccountList list = new AccountList();
        int choice;

        do {
            System.out.println("\n=== MENU QUẢN LÝ TÀI KHOẢN ===");
            System.out.println("1. Thêm tài khoản");
            System.out.println("2. Số TK hiện có");
            System.out.println("3. In thông tin tất cả TK");
            System.out.println("4. Nạp tiền vào TK");
            System.out.println("5. Rút tiền");
            System.out.println("6. Chuyển tiền");
            System.out.println("7. Kết thúc");
            System.out.print("Nhập lựa chọn (1-7): ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Xóa bộ đệm

            switch (choice) {
                case 1:
                    System.out.println("\nNhập thông tin tài khoản:");
                    System.out.print("Số TK: ");
                    long soTK = scanner.nextLong();
                    scanner.nextLine(); // Xóa bộ đệm
                    System.out.print("Tên TK: ");
                    String tenTK = scanner.nextLine();
                    System.out.print("Số tiền: ");
                    double soTien = scanner.nextDouble();
                    Account acc = new Account(soTK, tenTK, soTien);
                    if (list.themTaiKhoan(acc)) {
                        System.out.println("Thêm tài khoản thành công!");
                    } else {
                        System.out.println("Thêm tài khoản thất bại! (Danh sách đầy)");
                    }
                    break;

                case 2:
                    System.out.println("Số TK hiện có: " + list.tinhSoLuongTaiKhoan());
                    break;

                case 3:
                    System.out.println("\nThông tin tất cả TK:\n" + list.inThongTinTatCaTK());
                    break;

                case 4:
                    System.out.print("Nhập số TK muốn nạp tiền: ");
                    long soTKNap = scanner.nextLong();
                    Account accNap = list.timTaiKhoan(soTKNap);
                    if (accNap != null) {
                        System.out.print("Nhập số tiền nạp: ");
                        double soTienNap = scanner.nextDouble();
                        accNap.napTien(soTienNap);
                        System.out.println("Nạp tiền thành công! " + accNap);
                    } else {
                        System.out.println("Tài khoản không tồn tại!");
                    }
                    break;

                case 5:
                    System.out.print("Nhập số TK muốn rút tiền: ");
                    long soTKRut = scanner.nextLong();
                    Account accRut = list.timTaiKhoan(soTKRut);
                    if (accRut != null) {
                        System.out.print("Nhập số tiền rút: ");
                        double soTienRut = scanner.nextDouble();
                        accRut.rutTien(soTienRut);
                        System.out.println("Rút tiền thành công! " + accRut);
                    } else {
                        System.out.println("Tài khoản không tồn tại!");
                    }
                    break;

                case 6:
                    System.out.print("Nhập số TK gửi: ");
                    long soTKGui = scanner.nextLong();
                    Account accGui = list.timTaiKhoan(soTKGui);
                    System.out.print("Nhập số TK nhận: ");
                    long soTKNhan = scanner.nextLong();
                    Account accNhan = list.timTaiKhoan(soTKNhan);
                    if (accGui != null && accNhan != null) {
                        System.out.print("Nhập số tiền chuyển: ");
                        double soTienChuyen = scanner.nextDouble();
                        accGui.chuyenKhoan(accNhan, soTienChuyen);
                        System.out.println("Chuyển tiền thành công! " + accGui + "\n" + accNhan);
                    } else {
                        System.out.println("Một trong hai tài khoản không tồn tại!");
                    }
                    break;

                case 7:
                    System.out.println("Kết thúc chương trình!");
                    break;

                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng chọn lại.");
            }
        } while (choice != 7);

        scanner.close();
    }
}