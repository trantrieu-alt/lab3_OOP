import java.text.DecimalFormat;

public class Account {
    private long soTaiKhoan;
    private String tenTaiKhoan;
    private double soTien;
    private TrangThai trangThai;
    public static final double LAI_SUAT = 0.035;


    public enum TrangThai {
        ACTIVE("Đang hoạt động"),
        INACTIVE("Tạm đóng"),
        CLOSED("Bị Khoá");

        private final String moTa;

        TrangThai(String moTa) {
            this.moTa = moTa;
        }

        public String getMoTa() {
            return moTa;
        }
    }

    public Account() {
        this.soTaiKhoan = 999999;
        this.tenTaiKhoan = "chưa xác định";
        this.soTien = 50.0;
        this.trangThai = TrangThai.INACTIVE;
    }


    public Account(long soTaiKhoan, String tenTaiKhoan, double soTien) {
        setSoTaiKhoan(soTaiKhoan);
        setTenTaiKhoan(tenTaiKhoan);
        setSoTien(soTien);
    }


    public Account(long soTaiKhoan, String tenTaiKhoan) {
        setSoTaiKhoan(soTaiKhoan);
        setTenTaiKhoan(tenTaiKhoan);
        this.soTien = 50.0;
        this.trangThai = TrangThai.INACTIVE;
    }


    public long getSoTaiKhoan() {
        return soTaiKhoan;
    }

    public void setSoTaiKhoan(long soTaiKhoan) {
        if (soTaiKhoan <= 0 || soTaiKhoan == 999999) {
            this.soTaiKhoan = 999999;
            this.trangThai = TrangThai.INACTIVE;
        } else {
            this.soTaiKhoan = soTaiKhoan;
            this.trangThai = TrangThai.ACTIVE;
        }
    }

    public String getTenTaiKhoan() {
        return tenTaiKhoan;
    }

    public void setTenTaiKhoan(String tenTaiKhoan) {
        if (tenTaiKhoan == null || tenTaiKhoan.trim().isEmpty()) {
            this.tenTaiKhoan = "chưa xác định";
            this.trangThai = TrangThai.INACTIVE;
        } else {
            this.tenTaiKhoan = tenTaiKhoan.trim();
            this.trangThai = TrangThai.ACTIVE;
        }
    }

    public double getSoTien() {
        return soTien;
    }

    public void setSoTien(double soTien) {
        if (soTien < 50) {
            this.soTien = 50.0;
            this.trangThai = TrangThai.INACTIVE;
        } else {
            this.soTien = soTien;
            this.trangThai = TrangThai.ACTIVE;
        }
    }

    // nạp tiền
    public void napTien(double soTienNap) {
        if (soTienNap > 0) {
            this.soTien += soTienNap;
            this.trangThai = TrangThai.ACTIVE;
        } else {
            this.trangThai = TrangThai.INACTIVE;
        }
    }

    // rút tiền
    public void rutTien(double soTienRut) {
        if (soTienRut > 0 && soTienRut <= this.soTien) {
            this.soTien -= soTienRut;
            this.trangThai = TrangThai.ACTIVE;
        } else {
            this.trangThai = TrangThai.INACTIVE;
        }
    }

    // chuyển khoản
    public void chuyenKhoan(Account taiKhoanNhan, double soTienChuyen) {
        if (soTienChuyen > 0 && soTienChuyen <= this.soTien && taiKhoanNhan != null) {
            this.soTien -= soTienChuyen;
            taiKhoanNhan.napTien(soTienChuyen);
            this.trangThai = TrangThai.ACTIVE;
        } else {
            this.trangThai = TrangThai.INACTIVE;
        }
    }

    // Phương thức đáo hạn
    public void daoHan() {
        this.soTien += this.soTien * LAI_SUAT;
        this.trangThai = TrangThai.ACTIVE;
    }


    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#,###.##");
        return String.format("Số TK: %d, Tên TK: %s, Số tiền: %s VNĐ, Trạng thái: %s",
                soTaiKhoan, tenTaiKhoan, df.format(soTien), trangThai.getMoTa());
    }
}