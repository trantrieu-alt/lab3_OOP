/**
 * Class AccountList
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */
public class AccountList {
    private Account[] accList;
    private int count;


    public AccountList() {
        this.accList = new Account[10];
        this.count = 0;
    }

    public AccountList(int n) {
        this.accList = (n > 0) ? new Account[n] : new Account[10];
        this.count = 0;
    }

    // Thêm tài khoản
    public boolean themTaiKhoan(Account acc) {
        if (acc == null || count >= accList.length) {
            return false;
        }
        accList[count++] = acc;
        return true;
    }

    // Tìm tài khoản theo số TK
    public Account timTaiKhoan(long soTaiKhoan) {
        for (int i = 0; i < count; i++) {
            if (accList[i].getSoTaiKhoan() == soTaiKhoan) {
                return accList[i];
            }
        }
        return null;
    }

    // Xóa tài khoản theo số TK
    public boolean xoaTaiKhoan(long soTaiKhoan) {
        for (int i = 0; i < count; i++) {
            if (accList[i].getSoTaiKhoan() == soTaiKhoan) {
                for (int j = i; j < count - 1; j++) {
                    accList[j] = accList[j + 1];
                }
                accList[--count] = null;
                return true;
            }
        }
        return false;
    }

    // Tính số lượng tài khoản
    public int tinhSoLuongTaiKhoan() {
        return count;
    }

    // In thông tin tất cả TK
    public String inThongTinTatCaTK() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < count; i++) {
            result.append(accList[i].toString()).append("\n");
        }
        return result.toString();
    }
}