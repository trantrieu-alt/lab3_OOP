/**
 * Class CDTest
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */
import java.util.Scanner;

public class CDTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CDList danhSachCD = new CDList(5); // Khởi tạo danh sách với kích thước 5
        int choice;

        do {
            System.out.println("\n=== MENU QUẢN LÝ CD ===");
            System.out.println("1. Thêm CD");
            System.out.println("2. Số lượng CD");
            System.out.println("3. Tổng giá thành");
            System.out.println("4. Sắp xếp giảm dần theo giá thành");
            System.out.println("5. Sắp xếp tăng dần theo tựa CD");
            System.out.println("6. Hiển thị thông tin tất cả CD");
            System.out.println("7. Thoát");
            System.out.print("Nhập lựa chọn (1-7): ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("\nNhập thông tin CD:");
                    System.out.print("Mã CD: ");
                    int maCD = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Tựa CD: ");
                    String tuaCD = scanner.nextLine();
                    System.out.print("Số bài hát: ");
                    int soBaiHat = scanner.nextInt();
                    System.out.print("Giá thành: ");
                    double giaThanh = scanner.nextDouble();
                    CD cd = new CD(maCD, tuaCD, soBaiHat, giaThanh);
                    if (danhSachCD.themCD(cd)) {
                        System.out.println("Thêm CD thành công!");
                    } else {
                        System.out.println("Thêm CD thất bại! (Trùng mã / danh sách đầy)");
                    }
                    break;

                case 2:
                    System.out.println("Số lượng CD: " + danhSachCD.tinhSoLuongCD());
                    break;

                case 3:
                    System.out.println("Tổng giá thành: " + danhSachCD.tinhTongGiaThanh() + " VNĐ");
                    break;

                case 4:
                    danhSachCD.sapXepGiamDanTheoGiaThanh();
                    System.out.println("Đã sắp xếp giảm dần theo giá thành!");
                    break;

                case 5:
                    danhSachCD.sapXepTangDanTheoTuaCD();
                    System.out.println("Đã sắp xếp tăng dần theo tựa CD!");
                    break;

                case 6:
                    System.out.println("\nThông tin tất cả CD:\n" + danhSachCD.getThongTinTatCaCD());
                    break;

                case 7:
                    System.out.println("Thoát chương trình!");
                    break;

                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng chọn lại.");
            }
        } while (choice != 7);

        scanner.close();
    }
}