/**
 * Class CDList
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */
import java.util.Arrays;

public class CDList {
    private CD[] danhSachCD;
    private int soLuong;

    public CDList(int kichThuoc) {
        this.danhSachCD = new CD[kichThuoc];
        this.soLuong = 0;
    }

    public boolean themCD(CD cd) {
        if (cd == null || soLuong >= danhSachCD.length) {
            return false;
        }
        for (int i = 0; i < soLuong; i++) {
            if (danhSachCD[i].getMaCD() == cd.getMaCD()) {
                return false;
            }
        }
        danhSachCD[soLuong++] = cd;
        return true;
    }

    public int tinhSoLuongCD() {
        return soLuong;
    }

    public double tinhTongGiaThanh() {
        double tong = 0;
        for (int i = 0; i < soLuong; i++) {
            tong += danhSachCD[i].getGiaThanh();
        }
        return tong;
    }

    public void sapXepGiamDanTheoGiaThanh() {
        Arrays.sort(danhSachCD, 0, soLuong, (cd1, cd2) ->
                Double.compare(cd2.getGiaThanh(), cd1.getGiaThanh()));
    }

    public void sapXepTangDanTheoTuaCD() {
        Arrays.sort(danhSachCD, 0, soLuong, (cd1, cd2) ->
                cd1.getTuaCD().compareToIgnoreCase(cd2.getTuaCD()));
    }

    public String getThongTinTatCaCD() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < soLuong; i++) {
            result.append(danhSachCD[i].toString()).append("\n");
        }
        return result.toString();
    }
}