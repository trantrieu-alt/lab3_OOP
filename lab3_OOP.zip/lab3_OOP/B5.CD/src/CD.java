
/**
 * Class CD
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */
public class CD {
    private int maCD;
    private String tuaCD;
    private int soBaiHat;
    private double giaThanh;

    public CD() {
        this.maCD = 999999;
        this.tuaCD = "chưa xác định";
        this.soBaiHat = 1;
        this.giaThanh = 1.0;
    }

    public CD(int maCD, String tuaCD, int soBaiHat, double giaThanh) {
        setMaCD(maCD);
        setTuaCD(tuaCD);
        setSoBaiHat(soBaiHat);
        setGiaThanh(giaThanh);
    }

    public int getMaCD() {
        return maCD;
    }

    public void setMaCD(int maCD) {
        this.maCD = (maCD <= 0) ? 999999 : maCD;
    }

    public String getTuaCD() {
        return tuaCD;
    }

    public void setTuaCD(String tuaCD) {
        this.tuaCD = (tuaCD == null || tuaCD.trim().isEmpty()) ? "chưa xác định" : tuaCD.trim();
    }

    public int getSoBaiHat() {
        return soBaiHat;
    }

    public void setSoBaiHat(int soBaiHat) {
        this.soBaiHat = (soBaiHat <= 0) ? 1 : soBaiHat;
    }

    public double getGiaThanh() {
        return giaThanh;
    }

    public void setGiaThanh(double giaThanh) {
        this.giaThanh = (giaThanh <= 0) ? 1.0 : giaThanh;
    }

    @Override
    public String toString() {
        return String.format("Mã CD: %d, Tựa CD: %s, Số bài hát: %d, Giá thành: %.2f VNĐ",
                maCD, tuaCD, soBaiHat, giaThanh);
    }
}