

/**
 * Class HCN
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */

package iuh.fit.sv;


public class HinhChuNhat {
    private double chieuDai;
    private double chieuRong;

    public HinhChuNhat() {
        this.chieuDai = 0;
        this.chieuRong = 0;
    }

    public double getChieuDai() {
        return chieuDai;
    }

    public void setChieuDai(double chieuDai) {
        this.chieuDai = chieuDai;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }

    // Tính diện tích
    public double tinhDienTich() {
        return chieuDai * chieuRong;
    }

    // Tính chu vi
    public double tinhChuVi() {
        return 2 * (chieuDai + chieuRong);
    }

    @Override
    public String toString() {
        return "Hình chữ nhật: [Chiều dài = " + chieuDai +
                ", Chiều rộng = " + chieuRong +
                ", Diện tích = " + tinhDienTich() +
                ", Chu vi = " + tinhChuVi() + "]";
    }
}