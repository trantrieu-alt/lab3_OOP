
/**
 * Class Test
 * MSSV: 24698761
 * @author Trần Văn Triều
 * SunDay 21/09/2025
 */

package iuh.fit.sv;

import java.util.Scanner;

public class HCNTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HinhChuNhat hcn = new HinhChuNhat();

        System.out.print("Nhập chiều dài: ");
        double chieuDai = scanner.nextDouble();
        hcn.setChieuDai(chieuDai);

        System.out.print("Nhập chiều rộng: ");
        double chieuRong = scanner.nextDouble();
        hcn.setChieuRong(chieuRong);

        System.out.println(hcn.toString());
        scanner.close();
    }
}